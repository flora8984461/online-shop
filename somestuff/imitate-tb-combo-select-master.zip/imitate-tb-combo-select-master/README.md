# 仿淘宝套餐选择

<font size="4">**双击无法看到内容！**</font>

Demo 使用 Ajax 调用

放置于 Web Server 中访问，phpStudy 或 WAMP。目前仅提供 PHP 的数据，其它 Server 参考一下
